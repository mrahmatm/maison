<?php
$auth_type = "PER";
include 'connect.php';
include 'class.php';

$q = $_REQUEST["method"];

if ($q == "signUp") {
    // Process sign-up logic
    $patient_ICNum = $_REQUEST["patient_ICNum"];
    $patient_name = $_REQUEST["patient_name"];
    $patient_email = $_REQUEST["patient_email"];
    $patient_phoneNum = $_REQUEST["patient_phoneNum"];

    $create = new Patient($patient_ICNum, $patient_name, $patient_email, $patient_phoneNum);
    $status = $create->addPatient($conn);

    echo $status;
    
}
?>
